export default function Loding() {
  return (
    <div className="flex justify-center items-center h-[100vh]">
      <p>Chargement des produits...</p>
    </div>
  );
}
